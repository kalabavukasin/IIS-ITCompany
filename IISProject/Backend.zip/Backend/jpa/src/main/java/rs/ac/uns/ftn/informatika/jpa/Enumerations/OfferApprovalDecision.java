package rs.ac.uns.ftn.informatika.jpa.Enumerations;

public enum OfferApprovalDecision {
    APPROVED, REJECTED
}
