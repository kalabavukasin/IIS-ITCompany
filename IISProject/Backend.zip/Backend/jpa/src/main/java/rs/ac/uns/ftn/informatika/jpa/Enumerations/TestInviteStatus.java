package rs.ac.uns.ftn.informatika.jpa.Enumerations;

public enum TestInviteStatus {
    SENT, COMPLETED, VERIFIED, FAILED, EXPIRED
}
