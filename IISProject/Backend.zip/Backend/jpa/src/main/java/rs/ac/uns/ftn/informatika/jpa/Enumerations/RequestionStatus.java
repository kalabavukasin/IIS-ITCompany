package rs.ac.uns.ftn.informatika.jpa.Enumerations;

public enum RequestionStatus { DRAFT, PENDING_APPROVAL, APPROVED, REJECTED, CLOSED }
