package rs.ac.uns.ftn.informatika.jpa.Enumerations;

public enum OfferStatus {
     DRAFT, APPROVAL, APPROVED, SENT, ACCEPTED, DECLINED, WITHDRAWN, EXPIRED
}
