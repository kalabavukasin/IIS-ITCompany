package rs.ac.uns.ftn.informatika.jpa.Enumerations;

public enum RoleType {
    ADMIN, HRMANAGER, HIRINGMANAGER,INTERVIEWER, CANDIDATE
}
