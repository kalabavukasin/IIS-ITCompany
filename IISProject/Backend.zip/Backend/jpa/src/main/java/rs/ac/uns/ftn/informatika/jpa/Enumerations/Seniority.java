package rs.ac.uns.ftn.informatika.jpa.Enumerations;

public enum Seniority {
    INTERN,
    JUNIOR,
    MID,
    SENIOR,
    LEAD,
    PRINCIPAL
}
