package rs.ac.uns.ftn.informatika.jpa.Enumerations;

public enum AccountStatus {
    ACTIVE,
    INVITED,
    PENDING_VERIFICATION,
    BLOCKED,
    DISABLED
}
