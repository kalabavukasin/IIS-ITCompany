package rs.ac.uns.ftn.informatika.jpa.Enumerations;

public enum TestType { CODING, QUIZ, TAKE_HOME, LANGUAGE, OTHER }
