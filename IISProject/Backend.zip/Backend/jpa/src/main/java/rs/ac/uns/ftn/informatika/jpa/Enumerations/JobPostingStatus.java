package rs.ac.uns.ftn.informatika.jpa.Enumerations;

public enum JobPostingStatus { DRAFT, PUBLISHED, ARCHIVED }