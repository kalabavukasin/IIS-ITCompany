package rs.ac.uns.ftn.informatika.jpa.Enumerations;

public enum InterviewParticipantRole {
    INTERVIEWER, OBSERVER
}
