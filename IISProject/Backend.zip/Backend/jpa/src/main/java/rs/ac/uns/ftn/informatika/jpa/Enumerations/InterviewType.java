package rs.ac.uns.ftn.informatika.jpa.Enumerations;

public enum InterviewType { HR_SCREEN, TECHNICAL, SYSTEM_DESIGN, MANAGERIAL, FINAL }