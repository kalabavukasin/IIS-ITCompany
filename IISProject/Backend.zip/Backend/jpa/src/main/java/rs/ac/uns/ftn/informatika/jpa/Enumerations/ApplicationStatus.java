package rs.ac.uns.ftn.informatika.jpa.Enumerations;

public enum ApplicationStatus {
    ACTIVE, WITHDRAWN, REJECTED, HIRED
}
